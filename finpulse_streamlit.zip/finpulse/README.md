# 💰 FinPulse - Diagnóstico de Finanzas Personales

Encuesta interactiva de finanzas personales para estudiantes de posgrado en Marketing.

## 🚀 Características

- **19 preguntas** en 5 secciones: Gastos, Ahorro, Inversiones, Deuda y Planificación
- **Sistema de scoring** con 5 perfiles financieros (A+ a D)
- **Dashboard de resultados** con gráficos interactivos (gauge, radar, barras)
- **ADN Financiero** con etiquetas de comportamiento por estudiante
- **Correo automático** personalizado con recomendaciones
- **Panel de administración** con estadísticas agregadas y exportación CSV

## 📂 Estructura

```
finpulse/
├── app.py                    # Aplicación principal
├── requirements.txt          # Dependencias
├── secrets_template.toml     # Plantilla de credenciales SMTP
├── .streamlit/
│   └── config.toml           # Tema y configuración
└── README.md
```

## 🛠️ Instalación local

```bash
pip install -r requirements.txt
streamlit run app.py
```

## ☁️ Deploy en Streamlit Community Cloud

1. Sube el proyecto a tu repositorio de GitHub
2. Ve a [share.streamlit.io](https://share.streamlit.io)
3. Conecta el repo y selecciona `app.py`
4. En **Settings > Secrets**, agrega las credenciales SMTP si deseas envío automático

## 📧 Configuración de correo

### Opción 1: Generar y copiar (sin configuración)
El sistema genera el correo completo listo para copiar/pegar en tu cliente de correo.

### Opción 2: Envío automático por SMTP
Para Gmail:
1. Activa la verificación en 2 pasos en tu cuenta Google
2. Genera un App Password en https://myaccount.google.com/apppasswords
3. Configura las credenciales en la app o en `secrets.toml`

## 📊 Perfiles Financieros

| Grado | Perfil | Rango |
|-------|--------|-------|
| A+ | 🏆 Maestro Financiero | 85-100% |
| A | ⭐ Estratega Financiero | 70-84% |
| B | 📘 Aprendiz Financiero | 55-69% |
| C | ⚠️ En Zona de Riesgo | 35-54% |
| D | 🚨 Alerta Financiera | 0-34% |
